<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Paketan_pesanan extends Model
{
    protected $table = 'paketan_pesanan';
}

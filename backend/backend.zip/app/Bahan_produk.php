<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bahan_produk extends Model
{
    protected $table = 'bahan_produk';
}

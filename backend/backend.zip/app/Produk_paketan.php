<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Produk_paketan extends Model
{
    protected $table = 'paketan_produk';
}
